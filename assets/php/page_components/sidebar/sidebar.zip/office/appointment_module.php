<li>
    <a href="#" mm-active="new-appointment|view-appointments|print-appointments">
        <i class="metismenu-icon pe-7s-albums"></i> Appointments
        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
    </a>
    <ul>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>office/appointments/new-appointment" mm-active="new-appointment">
                <i class="metismenu-icon"></i> New Appointment
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>office/appointments/view-appointments" mm-active="view-appointments">
                <i class="metismenu-icon"></i> View Appointments
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>office/appointments/print-appointments" mm-active="print-appointments">
                <i class="metismenu-icon"></i> Print Appointments
            </a>
        </li>
    </ul>
</li>