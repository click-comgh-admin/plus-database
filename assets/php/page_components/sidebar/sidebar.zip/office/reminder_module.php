<li>
    <a href="#" mm-active="new-reminder|view-reminders|print-reminders">
        <i class="metismenu-icon pe-7s-alarm"></i> Reminders
        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
    </a>
    <ul>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>office/reminders/new-reminder" mm-active="new-reminder">
                <i class="metismenu-icon"></i> New Reminder
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>office/reminders/view-reminders" mm-active="view-reminders">
                <i class="metismenu-icon"></i> View Reminders
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>office/reminders/print-reminders" mm-active="print-reminders">
                <i class="metismenu-icon"></i> Print Reminders
            </a>
        </li>
    </ul>
</li>