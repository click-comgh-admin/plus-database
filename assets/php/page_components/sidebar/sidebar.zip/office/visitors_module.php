<li>
    <a href="#" mm-active="new-visitor|view-visitors|print-visitors">
        <i class="metismenu-icon pe-7s-users"></i> Visitors
        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
    </a>
    <ul>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>office/visitors/new-visitor" mm-active="new-visitor">
                <i class="metismenu-icon"></i> New Visitor
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>office/visitors/view-visitors" mm-active="view-visitors">
                <i class="metismenu-icon"></i> View Visitors
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>office/visitors/print-visitors" mm-active="print-visitors">
                <i class="metismenu-icon"></i> Print Visitors
            </a>
        </li>
    </ul>
</li>