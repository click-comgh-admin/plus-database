<li class="app-sidebar__heading">Communications</li>
<?php 
    require_once "attendance/attendance-meeting_module.php";
?>
<li class="app-sidebar__heading">Attendance</li>
<?php 
    require_once "attendance/attendance-registration_module.php";
    require_once "attendance/attendance_module.php";
?>
