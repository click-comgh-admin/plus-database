<li>
    <a href="<?= CLIENT_BASE_URL; ?>" mm-active="|index">
        <i class="metismenu-icon pe-7s-home"></i> Home
    </a>
</li>