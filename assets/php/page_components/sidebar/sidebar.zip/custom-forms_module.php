<li>
    <a href="#" mm-active="create-form|custom-form">
        <i class="metismenu-icon pe-7s-note"></i> Custom Registration
        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
    </a>
    <ul>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>custom-forms/custom-form" mm-active="custom-form">
                <i class="metismenu-icon"></i> Forms
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>custom-forms/create-form" mm-active="create-form">
                <i class="metismenu-icon"></i> Create Form(s)
            </a>
        </li>
    </ul>
</li>