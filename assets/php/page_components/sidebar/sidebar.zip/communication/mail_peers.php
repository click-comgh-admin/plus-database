
<li>
    <a href="#" mm-active="peers">
        <i class="metismenu-icon pe-7s-id"></i> Peer Mail
        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
    </a>
    <ul>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>communications/peers?messages" mm-active="peers">
                <i class="metismenu-icon">
                </i>Messages
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>communications/peers?inbox" mm-active="peers">
                <i class="metismenu-icon">
                </i>Inbox
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>communications/peers?outbox" mm-active="peers">
                <i class="metismenu-icon">
                </i>Outbox
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>communications/peers?compose" mm-active="peers">
                <i class="metismenu-icon">
                </i>Compose
            </a>
        </li>
    </ul>
</li>