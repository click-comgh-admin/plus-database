
<li>
    <a href="#" mm-active="contacts">
        <i class="metismenu-icon pe-7s-phone"></i> Contact Book Mail
        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
    </a>
    <ul>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>communications/contacts?inbox" mm-active="contacts">
                <i class="metismenu-icon">
                </i>Inbox
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>communications/contacts?outbox" mm-active="contacts">
                <i class="metismenu-icon">
                </i>Outbox
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>communications/contacts?compose" mm-active="contacts">
                <i class="metismenu-icon">
                </i>Compose
            </a>
        </li>
    </ul>
</li>