<li class="app-sidebar__heading">Contact Bank</li>
<li>
    <a href="#" mm-active="contact-access-code|contact-group">
        <i class="metismenu-icon pe-7s-phone pe-7s-notebook"></i> Contact Bank 
        <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>
    </a>
    <ul>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>communication" mm-active="communication">
                <i class="metismenu-icon pe-7s-mail-open-file"></i> Contacts
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>communications/contact/contact-agent" mm-active="contact-agent">
                <i class="metismenu-icon">
                </i> Contact Agent(s)
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>communications/contact/contact-access-code" mm-active="contact-access-code">
                <i class="metismenu-icon">
                </i> Contact Form Access Code
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>communications/contact/contact-group" mm-active="contact-group">
                <i class="metismenu-icon">
                </i> Contact Groups
            </a>
        </li>
        <li>
            <a href="<?= CLIENT_BASE_URL; ?>communications/contact/connect-to-nstacom" mm-active="connect-to-nstacom">
                <i class="metismenu-icon">
                </i> Connect to Nstacom
            </a>
        </li>
        <li>
            <a href="https://app.nstacom.com/" target="_blank">
                <i class="metismenu-icon">
                </i> Go to Nstacom
            </a>
        </li>
    </ul>
</li>