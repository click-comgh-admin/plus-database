<li>
    <a href="<?= CLIENT_BASE_URL; ?>communications/credit" mm-active="credit">
        <i class="metismenu-icon pe-7s-wallet"></i> Credit
    </a>
</li>
<li>
    <a href="<?= CLIENT_BASE_URL; ?>communications/sms-id" mm-active="sms-id">
        <i class="metismenu-icon pe-7s-id"></i> SMS ID
    </a>
</li>