<li class="app-sidebar__heading">File Manager</li>
<li>
    <a href="<?= CLIENT_BASE_URL; ?>file-manager/folder" mm-active="folder|subfolder|file">
        <i class="metismenu-icon pe-7s-folder"></i> Home
    </a>
</li>
<li>
    <a href="<?= CLIENT_BASE_URL; ?>file-manager/finder" mm-active="finder">
        <i class="metismenu-icon pe-7s-search"></i> File Finder
    </a>
</li>
<li>
    <a href="<?= CLIENT_BASE_URL; ?>file-manager/archive" mm-active="archive">
        <i class="metismenu-icon pe-7s-wristwatch"></i> File Archive
    </a>
</li>